package uni.aed.directorio;

import java.util.InputMismatchException;
import java.util.Scanner;
import uni.aed.model.Persona;

public class DirectorioMain {
    private static final Scanner scr = new Scanner(System.in).useDelimiter("\n");
    private final Directorio directorio;
    
    public DirectorioMain() {
        directorio = new DirectorioV1(10); 
    }
    
    public static void main(String[] args) {
        DirectorioMain directorioMain = new DirectorioMain();
        directorioMain.menu();        
    }    
    
    private void menu() {
        String SEPARADOR = "\n";
        int opcion = 0;
        
        try {
            do {
                System.out.println("Demostración HeapSort " + SEPARADOR +
                    "a) Registrar Personas en Directorio " + SEPARADOR +                    
                    "b) Ordenar Personas con método HeapSort " + SEPARADOR +
                    "c) Visualizar Directorio " + SEPARADOR +                    
                    "d) Salir " + SEPARADOR + "Elija una opcion:");
                
                String opcionStr = scr.next();
                
                switch(opcionStr.toLowerCase()) {
                    case "a" -> registrarPersonas();
                    case "b" -> ordenarHeapSort();
                    case "c" -> visualizarDirectorio();
                    case "d" -> {
                        System.out.println("Saliendo del programa...");
                        return;
                    }
                    default -> System.out.println("Opción inválida. Intente nuevamente.");
                }                
            } while (opcion != 'd');            
        } catch(InputMismatchException e) {
            System.out.println("Debe ingresar una opción válida: " + e.toString());
        } catch(Exception e) {
            System.out.println("Se presentó un error: " + e.toString());
        }
    }
    
    private void registrarPersonas() {
        try {
            System.out.println("Ingrese el nombre de la persona:");
            String nombre = scr.next();
            
            System.out.println("Ingrese la edad de la persona:");
            int edad = scr.nextInt();
            
            System.out.println("Ingrese el género de la persona (M/F):");
            String generoStr = scr.next();
            char genero = generoStr.toUpperCase().charAt(0);
            
            if (genero != 'M' && genero != 'F') {
                System.out.println("Género inválido. Se asignará M por defecto.");
                genero = 'M';
            }
            
            Persona persona = new Persona(nombre, edad, genero);
            directorio.add(persona);
            
            System.out.println("Persona registrada exitosamente.");
        } catch (InputMismatchException e) {
            System.out.println("Error en el formato de entrada: " + e.toString());
            scr.next(); 
        } catch (Exception e) {
            System.out.println("Error al registrar la persona: " + e.toString());
        }
    }
    
    private void ordenarHeapSort() {
        try {
            if (directorio.toString().isEmpty()) {
                System.out.println("El directorio está vacío. Registre personas primero.");
                return;
            }
            
            System.out.println("Ordenar por:");
            System.out.println("1. Nombre");
            System.out.println("2. Edad");
            int opcion = scr.nextInt();
            
            int atributo;
            switch (opcion) {
                case 1 -> {
                    atributo = Persona.NAME;
                    System.out.println("Ordenando por Nombre usando HeapSort...");
                }
                case 2 -> {
                    atributo = Persona.AGE;
                    System.out.println("Ordenando por Edad usando HeapSort...");
                }
                default -> {
                    System.out.println("Opción inválida. Ordenando por Nombre por defecto.");
                    atributo = Persona.NAME;
                }
            }
            
            Object[] sortedList = directorio.sortHeapSort(atributo);
            
            System.out.println("Personas ordenadas con HeapSort:");
            for (Object obj : sortedList) {
                if (obj != null) {
                    Persona p = (Persona) obj;
                    System.out.println(p.toString());
                }
            }
        } catch (InputMismatchException e) {
            System.out.println("Error en el formato de entrada: " + e.toString());
            scr.next(); 
        } catch (Exception e) {
            System.out.println("Error al ordenar: " + e.toString());
        }
    }
    
    private void visualizarDirectorio() {
        if (directorio.toString().isEmpty()) {
            System.out.println("El directorio está vacío. Registre personas primero.");
            return;
        }        
        System.out.println("Contenido del Directorio:");
        System.out.println(directorio.toString());
    }
}