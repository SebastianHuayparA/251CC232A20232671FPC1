/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package uni.aed.cc232aproject;
import uni.aed.sort.matriz.MatrizApp;

/**
 *
 * @author zemr
 */
public class App {

    public static void main(String[] args) {
        MatrizApp app = new MatrizApp();
        app.mostrarMenu();
    }
}



