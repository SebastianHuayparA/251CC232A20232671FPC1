package uni.aed.sort;
public class SortObject {    
    private Object[] X;

    public void setX(Object[] X) {
        this.X = X;
    }

    public Object[] getX() {
        return X;
    }
    
    public void callHeapSort(){
        heapSort(X);
    }

    private void heapSort(Object[] X) {
        int n = X.length;
        
        for (int i = n / 2 - 1; i >= 0; i--)
            heapify(X, n, i);
        
        for (int i = n - 1; i > 0; i--) {
            Object temp = X[0];
            X[0] = X[i];
            X[i] = temp;
            
            heapify(X, i, 0);
        }
    }
    
    // Función para heapify un subárbol con raíz en el índice i
    private void heapify(Object[] X, int n, int i) {
        int largest = i;  // Inicializar largest como raíz
        int left = 2 * i + 1;  // Izquierdo = 2*i + 1
        int right = 2 * i + 2;  // Derecho = 2*i + 2
        int compareResult;
        
        // Si el hijo izquierdo es más grande que la raíz
        if (left < n) {
            compareResult = ((Comparable)X[left]).compareTo(X[largest]);
            if (compareResult > 0)
                largest = left;
        }
        
        // Si el hijo derecho es más grande que largest hasta ahora
        if (right < n) {
            compareResult = ((Comparable)X[right]).compareTo(X[largest]);
            if (compareResult > 0)
                largest = right;
        }
        
        // Si largest no es la raíz
        if (largest != i) {
            Object swap = X[i];
            X[i] = X[largest];
            X[largest] = swap;
            
            // Recursivamente heapify el subárbol afectado
            heapify(X, n, largest);
        }
    }

    @Override
    public String toString() {
        if (X==null) return "";
        StringBuilder str=new StringBuilder();
        for(Object x:X)
            if(str.isEmpty())
                str.append(x.toString());
            else
                str.append("|").append(x.toString());
        
        return "{"+str.toString()+"}";   
    }

    void callMergeSort() { // Esto es para que el Sort.java no lance error
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}