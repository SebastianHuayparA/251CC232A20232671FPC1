package uni.aed.directorio;

import uni.aed.model.Persona;

public interface Directorio {
    void add(Persona p);
    boolean delete(String searchName);
    Persona search(String searchName);
    Persona[] sort(int attribute);
    Object[] sort(int attribute, String algoritmo);
    int search(Object searchValue, String algoritmo);
    
    // Método para ordenar con HeapSort
    Object[] sortHeapSort(int attribute);
}