/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uni.aed.sort.matriz;
import uni.aed.sort.Sort;
import java.util.Random;
import java.util.Scanner;

public class MatrizApp {
    
    private int[] serie;
    private int[][] matriz;
    private int n; 
    private final Sort sorter;
    private final Scanner sc;
    
    public MatrizApp() {
        sorter = new Sort();
        sc = new Scanner(System.in);
        serie = null;
        matriz = null;
    }
    public void Serie() { // Generamos la serie
        serie = new int[100];
        Random rand = new Random();
        for (int i = 0; i < serie.length; i++) {
            serie[i] = rand.nextInt(101) + 100; // Acotamos para números entre 100 y 200
        }
        System.out.println("¡Serie generada correctamente!");
    }
    
    public void ordenarSerie() { // Hacemos uso del método QuickSort de la clase Sort.java
        if (serie == null) { // Si la serie está vacía, pedimos que primero se genere
            System.out.println("¡No hay ninguna serie! Por favor genérela.");
            return;
        }
        sorter.quickSort(serie); // Ordenamos de mayor a menor
        System.out.println("¡Serie completamente ordenada de mayor a menor!");
    }
    
    public void visualizarSerie() {
        if (serie == null) { // Comprobamos aquí también que exista una serie
            System.out.println("¡No hay ninguna serie! Por favor genérela.");
            return;
        }
        
        System.out.println("La serie es:");
        for (int i = 0; i < serie.length; i++) {
            System.out.print(serie[i] + " ");
            if ((i + 1) % 10 == 0) {
                System.out.println(); // Hacemos un salto de linea cada 10 elementos para un correcto formateo del output
            }
        }
        System.out.println();
    }
    
    public void cargarMatriz() { // Cargamos la matriz
        if (serie == null) { // Aquí comprobamos la existencia de la serie nuevamente
            System.out.println("¡No hay ninguna serie! Por favor genérela.");
            return;
        }

        System.out.print("Ingrese el n (tamaño de la matriz): "); // Pedimos que ingrese el valor de "n"
        n = sc.nextInt();
        
        if (n*n % 4 != 0) { // Validamos que n*n sea multiplo de 4 para que se pueda tener un cuadrante exacto 
            System.out.println("¡n*n debe ser múltiplo de 4!");
            return;
        } // También se podría hacer con n*n no multiplo de 4 con un condicional en la parte de startRow y startCol. Pero estoy siguiendo las indicanciones del word
        
        matriz = new int[n][n]; // Inicializamos la matriz con 0s

        int elementosNecesarios = n*n / 4; // Calculamos la cantidad de elementos necesarios
        
        if (elementosNecesarios > serie.length) { // Verificamos que tengamos suficientes elementos en la serie
            System.out.println("¡Cantidad de elementos insuficiente para llenar el cuadrante!");
            return;
        }
        
        if (!ComprobarSerieOrdenada()) { // Corroboramos que la serie esté correctamente ordenadaa
            System.out.println("La serie no estaba ordenadada ¡Ordenando automaticamente!");
            ordenarSerie(); // En caso no esté, ordenamos automaticamente la serie
        }
        
        int serieIndex = 0; // Llenamos el cuadrante desde el inicio de la serie ya ordenada        
        int startRow = (2 * n / 4);
        int startCol = (2 * n / 4);
        
        for (int i = startRow; i < n; i++) {
            for (int j = startCol; j < n; j++) {
                if (serieIndex < elementosNecesarios) {
                    matriz[i][j] = serie[serieIndex++];
                }
            }
        }    
        System.out.println("¡Se cargó la matriz de manera exitosa! Se añadieron los " + elementosNecesarios + 
                          " mayores valores en el último cuadrante.");
    }
    
    private boolean ComprobarSerieOrdenada() { // Este es el método que usamos para comprobar el ordenamiento de la serie en la línea 82
        if (serie == null || serie.length <= 1) {
            return true;
        }
        for (int i = 0; i < serie.length - 1; i++) {
            if (serie[i] < serie[i + 1]) {
                return false;
            }
        }     
        return true;
    }
    
    public void visualizarMatriz() { 
        if (matriz == null) { // Nos percatamos de que la matriz esté cargada primeramente
            System.out.println("¡Ey, Primero debe cargar la matriz!");
            return;
        }
        System.out.println("Matriz " + n + "x" + n + ":"); // Mostramos al matriz
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.printf("%4d ", matriz[i][j]); // Alineamos de manera correcta
            }
            System.out.println();
        }
    }
    
    public void mostrarMenu() { // Mostramos el menú de opciones que pide el word
        
        do {
            System.out.println("\n¡Bienvenid@ al menú de MatrizApp!");
            System.out.println("a) Generar Serie");
            System.out.println("b) Ordenar Serie");
            System.out.println("c) Visualizar Serie");
            System.out.println("d) Cargar Matriz");
            System.out.println("e) Visualizar Matriz");
            System.out.println("f) Salir");
            System.out.print("Seleccione una opción: ");
            
            String entrada = sc.next();
            
            switch (entrada.toLowerCase()) {
                case "a" -> Serie();
                case "b" -> ordenarSerie();
                case "c" -> visualizarSerie();
                case "d" -> cargarMatriz();
                case "e" -> visualizarMatriz();
                case "f" -> {
                    System.out.println("¡Hasta pronto! Gracias por visitar MatrizApp");
                    return;
                }
                default -> System.out.println("Escoja una opción válida"); // Verificamos que la opción escogida sea válida
            }
            
        } while (true);
    }
    
    // Método principal para ejecutar la aplicación
    public static void main(String[] args) {
        MatrizApp app = new MatrizApp();
        app.mostrarMenu();
    }
}
